http://pysalt.salt.ac.za/lineatlas/
